#################################################################################################################
# DATE: 26 August, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
# NOTE: THIS FUNCTION ALSO CONTAINS CODE ORIGINALLY FROM THE SIRAD PACKAGE under the GPL-2 licence (see below!)
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################
# NOTE: DETAILS OF THE SIRAD PACKAGE
#################################################################################################################
# sirad: Functions for calculating daily solar radiation and evapotranspiration
#
# Author:  Jedrzej S. Bojanowski
# Maintainer:	Jedrzej S. Bojanowski <jedrzej.bojanowski at gmail.com>
# License:	GPL-2
# URL:	http://sirad.r-forge.r-project.org/, http://mars.jrc.ec.europa.eu/mars/Projects/Solar-Radiation-in-MCYFS, 
# http://jbojanowski.pl
#################################################################################################################
sirad.exh <-
  function(i,lat,hr=NA,Con=4.921) {
    if (is.na(hr)) {
      vshr <- vector()
      for (ho in 0:23) {
        vshr <- c(vshr,Con*sirad.corrEarthSunDist(i)*cos(sirad.solarZenithAngle(lat,ho,i)))
      }
      shr <- vshr
    }
    if (is.numeric(hr)) {
      shr <- Con*sirad.corrEarthSunDist(i)*cos(sirad.solarZenithAngle(lat,hr,i))  
    }
    shr #[MJ]
  }