# flux.gpp.R
#################################################################################################################
# DATE: 29 May, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################
#
flux.gpp<-function(regression.results,monthly.flux, month.frmtd.dhT, frmtd.dhT, tower.name, cur.year,cur.month, run.id,out.file.path){
  # Calculate GPP
  gf.gpp <- regression.results$amax * monthly.flux$Gflux.PPFD / (monthly.flux$Gflux.PPFD + regression.results$c) # GPP equation
  # Create and initialize the output files:
  hh.output.file <- paste("hh/",run.id,"_",tower.name,"_stats.csv", sep="")
  dd.output.file <- paste("dd/",run.id,"_",tower.name,"_stats.csv", sep="")
  mm.output.file <- paste("mm/",run.id,"_",tower.name,"_stats.csv", sep="")
  ######################################################################################################################
  # FLUXNET Notes on daily calculation conversions:    								                                                 #
  # mol/m2/d = umol/m2/s * (3600 sec/hr) * (24 hr/day) * (10**-6  mol/umol) = 0.0864 * umol/m2/s										   #
  # MJ/m2/d = W/m2 * (3600 sec/hr) * (24 hr/day) * (10**-6  MJ/W) = 0.0864 * W/m2									                     #	
  # gC/m2/d = umol/m2/s * (3600 sec/hr) * (24 hr/day) * (12.011 gc/mol) * (10**-6  mol/umol) = 1.0377504 * W/m2			   #							
  ######################################################################################################################
  # ePiSaT scaling factors
  fac.gc=30*60*12.011*10^-6 # seconds to 30min GPP to grams C : 30mins . 60Secs . 12.011 (mol.C) . 10^-6 (umol to mol)
  fac.mc=30*60*10^-6 # seconds to 30 min GPP to mol : 30mins . 60Secs . 12.011 (mol.C) . 10^-6 (umol to mol)
  fac.ppfd=30*60 # # seconds to 30 min PPFD : 30mins . 60Secs
  fac.mppfd=30*60*10^-6 # seconds to 30 min PPFD to mol : 30mins . 60Secs . 10^-6 (umol to mol) 
  ######################################################################################################################
  # Hourly GPP
  #
  # Calculate hourly GPP integral
  hh.gpp.umol=as.numeric(gf.gpp$Gflux.PPFD) # gpp in umolC m2 s-1
  hh.gpp.gc=gf.gpp*fac.gc  # gpp in gC m2 30mins-1
  hh.gpp.mol=gf.gpp*fac.mc # gpp in molC m2 30mins-1
  #
  # TODO : Impliment outlier removal
  #
  # Write the new line
  hh.out.line <- paste(tower.name,",",cur.year,",",cur.month,",",
                       format(strptime(index(gf.gpp), format="%Y-%m-%d %H:%M:%S"), "%d"),",",
                       format(strptime(index(gf.gpp), format="%Y-%m-%d %H:%M:%S"), "%H"),",",
                       format(strptime(index(gf.gpp), format="%Y-%m-%d %H:%M:%S"), "%M"),",",
                       hh.gpp.umol,",",hh.gpp.gc,",", hh.gpp.mol,",",
                       monthly.flux$Gflux.PPFD,",",regression.results$amax,",",regression.results$r,",", regression.results$phi,",",
                       kEstimators[["a"]],",", kEstimators[["b"]],",", kEstimators[["c"]],",",
                       regression.results$r2adj,",",regression.results$a,",", regression.results$b,",", regression.results$c,",",regression.results$rmse,",",
                       regression.results$a.sterr,",",regression.results$b.sterr,",",regression.results$c.sterr,",",
                       month.frmtd.dhT$TA,",",month.frmtd.dhT$RH, sep=" ")
  write(hh.out.line,file.path(out.file.path, "/",run.id, hh.output.file),append=TRUE,sep="")
  ###########################################################################
  # Daily GPP
  #
  # Calculate daily GPP & PPFD integral:
  dd.gf.ppfd<-as.numeric(period.apply(monthly.flux$Gflux.PPFD, endpoints(monthly.flux$Gflux.PPFD, "days"), sum))  # ppfd in umol m2 s-1
  dd.gf.ppfd.umol<-dd.gf.ppfd*fac.ppfd
  dd.gf.ppfd.mol<-dd.gf.ppfd*fac.mppfd
  dd.gpp.umol<-as.numeric(period.apply(gf.gpp$Gflux.PPFD, endpoints(gf.gpp$Gflux.PPFD, "days"), sum))  # gpp in umolC m2 d-1
  dd.gpp.gc=dd.gpp.umol*fac.gc # gpp in gC m2 day-1
  dd.gpp.mol=dd.gpp.umol*fac.mc # gpp in molC m2 day-1 
  # Calculate the T integrals:
  dd.tair<-xts(month.frmtd.dhT$TA,strptime(month.frmtd.dhT$TimeStamp,time.format,tz="UTC")) # Make a time indexed tair time series
  dd.rh<-xts(month.frmtd.dhT$RH,strptime(month.frmtd.dhT$TimeStamp,time.format,tz="UTC")) # Make a time indexed tair time series
  dd.ave.rh <- as.numeric(period.apply(dd.rh[,1], endpoints(dd.rh, "days"), mean))  # tair in degrees C
  dd.ave.tair <- as.numeric(period.apply(dd.tair[,1], endpoints(dd.tair[,1], "days"), mean))  # tair in degrees C
  dd.min.tair <- as.numeric(period.apply(dd.tair[,1], endpoints(dd.tair[,1], "days"), min))   # tair in degrees C
  dd.max.tair <- as.numeric(period.apply(dd.tair[,1], endpoints(dd.tair[,1], "days"), max))   # tair in degrees C
  dd.ran.tair <-  as.numeric(period.apply(dd.tair[,1], endpoints(dd.tair[,1], "days"), max))-as.numeric(period.apply(dd.tair[,1], endpoints(dd.tair[,1], "days"), min)) # tair in degrees C
  # Write the new line
  dd.out.line <- paste(tower.name,",",cur.year,",",cur.month,",", unique(month.frmtd.dhT$Day),",",
                       dd.gpp.umol,",",dd.gpp.gc,",", dd.gpp.mol,",",
                       dd.gf.ppfd.umol,",",dd.gf.ppfd.mol,",",regression.results$amax,",",regression.results$r,",", regression.results$phi,",",
                       kEstimators[["a"]],",", kEstimators[["b"]],",", kEstimators[["c"]],",",
                       regression.results$r2adj,",",regression.results$a,",", regression.results$b,",", regression.results$c,",",regression.results$rmse,",",
                       regression.results$a.sterr,",",regression.results$b.sterr,",",regression.results$c.sterr,",",
                       dd.ave.tair,",",dd.min.tair,",",dd.max.tair,",",dd.ran.tair, ",", dd.ave.rh,
                       sep=" ")
  write(dd.out.line,file.path(out.file.path, "/",run.id, dd.output.file),append=TRUE,sep="")
  ###########################################################################
  # Monthly GP
  #
  # Calculate monthly GPP and PPFD integral
  mm.gf.ppfd<-as.numeric(period.apply(monthly.flux$Gflux.PPFD, endpoints(monthly.flux$Gflux.PPFD, "months"), sum))  # ppfd in umol m2 s-1
  mm.gf.ppfd.umol<-sum(dd.gf.ppfd)*fac.ppfd
  mm.gf.ppfd.mol<-sum(dd.gf.ppfd)*fac.mppfd
  mm.gpp.umol<-as.numeric(period.apply(gf.gpp$Gflux.PPFD, endpoints(gf.gpp$Gflux.PPFD, "months"), sum))  # gpp in umolC m2 d-1
  #mm.gpp.umol=sum(gf.gpp)  # gpp in umolC m2 month-1
  mm.gpp.gc=mm.gpp.umol*fac.gc # gpp in gC m2 month-1
  mm.gpp.mol=mm.gpp.umol*fac.mc# gpp in molC m2 month-1
  # Calculate the T integrals:
  mm.tair<-xts(month.frmtd.dhT$TA,strptime(month.frmtd.dhT$TimeStamp,time.format,tz="UTC")) # Make a time indexed tair time series
  mm.rh<-xts(month.frmtd.dhT$RH,strptime(month.frmtd.dhT$TimeStamp,time.format,tz="UTC")) # Make a time indexed tair time series
  mm.ave.rh   <- as.numeric(period.apply(mm.rh[,1], endpoints(mm.rh[,1], "months"), mean))  # tair in degrees C
  mm.ave.tair <- as.numeric(period.apply(mm.tair[,1], endpoints(mm.tair[,1], "months"), mean))  # tair in degrees C
  mm.min.tair <- min(as.numeric(mm.tair[,1]))   # tair in degrees C
  mm.max.tair <- max(as.numeric(mm.tair[,1]))   # tair in degrees C
  mm.ran.tair <- max(as.numeric(mm.tair[,1]))-min(as.numeric(mm.tair[,1])) # tair in degrees C 
  #mm.min.tair <- as.numeric(period.apply(mm.tair[,1], endpoints(mm.tair[,1], "months"), min))   # tair in degrees C
  #mm.max.tair <- as.numeric(period.apply(mm.tair[,1], endpoints(mm.tair[,1], "months"), max))   # tair in degrees C
  #mm.ran.tair <- as.numeric(period.apply(mm.tair[,1], endpoints(mm.tair[,1], "months"), max))-as.numeric(period.apply(mm.tair[,1], endpoints(mm.tair[,1], "months"), min)) # tair in degrees C
  # Write the new line
  mm.out.line <- paste(tower.name,",",cur.year,",",cur.month,",",
                     mm.gpp.umol,",",mm.gpp.gc,",", mm.gpp.mol,",",
                     mm.gf.ppfd.umol,",",mm.gf.ppfd.mol,",",regression.results$amax,",",regression.results$r,",", regression.results$phi,",",
                     kEstimators[["a"]],",", kEstimators[["b"]],",", kEstimators[["c"]],",",
                     regression.results$r2adj,",",regression.results$a,",", regression.results$b,",", regression.results$c,",",regression.results$rmse,",",
                     regression.results$a.sterr,",",regression.results$b.sterr,",",regression.results$c.sterr,",",
                     mm.ave.tair,",",mm.min.tair,",",mm.max.tair,",",mm.ran.tair, ",", mm.ave.rh,
                     sep=" ")
  write(mm.out.line,file.path(out.file.path, "/",run.id, mm.output.file),append=TRUE,sep="") # Write the line to file
  #
  remove(dd.out.line,hh.out.line,mm.out.line)
  # Return molar scaled estimates of gpp and ppfd
  #cbind(mm.gpp.mol,mm.gf.ppfd.mol)
  mm.gpp.mol
}