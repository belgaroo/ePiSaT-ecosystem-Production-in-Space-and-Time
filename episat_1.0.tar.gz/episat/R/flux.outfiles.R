# flux.outfiles.R
#################################################################################################################
# DATE: 29 May, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans, Colin Prentice, Tyler W. Davis, Xavier Gilbert
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################
flux.outfiles<-function(out.file.path, run.id, tower.name){
#
if (!file.exists(paste(out.file.path, "/", run.id,sep=""))){
  ###############################################
  # Create the output directory structure
  dir.create(paste(out.file.path, "/", run.id, sep=""))
  dir.create(paste(out.file.path, "/", run.id,"/hh",sep=""))
  dir.create(paste(out.file.path, "/", run.id,"/dd",sep=""))
  dir.create(paste(out.file.path, "/", run.id,"/mm",sep=""))
  dir.create(paste(out.file.path, "/", run.id,"/pdf",sep=""))
  ###############################################
 cat("Succesfully created output directory", "\n")
}  

# Hourly  
# Create and initialize the output files:
hh.output.file <- paste("hh/",run.id,"_",tower.name,"_stats.csv", sep="")
# Write the hourly output file:
hh.out.header<-paste("site","year","month","day","hour","minute",
                     "GPP.umol","GPP.g", "GPP.mol", 
                     "gf.PPFD", "Amax", "R", "phi", 
                     "start_a","start_b", "start_c", 
                     "RsqAdj",  "fit_a", "fit_b", "fit_c",  "RMSE",
                     "ster_a", "ster_b", "ster_c",
                     "Tair","RH", sep=",")
write(hh.out.header, file.path(out.file.path, "/",run.id, hh.output.file), append=TRUE, sep="") # file.path builds the path to the file and creates the file
#############################
# Daily
# Create the output filename:
dd.output.file  <- paste("dd/",run.id,"_",tower.name,"_stats.csv", sep="")
# Write the daily output file:
dd.out.header<-paste("site","year","month","day",
                     "GPP.umol","GPP.g", "GPP.mol", 
                     "gf.PPFD.umol","gf.PPFD.mol", "Amax", "R", "phi", 
                     "start_a","start_b", "start_c", 
                     "RsqAdj",  "fit_a", "fit_b", "fit_c",  "RMSE",
                     "ster_a", "ster_b", "ster_c",
                     "Tmean","Tmin", "Tmax", "Trange", "RH", sep=",")
write(dd.out.header, file.path(out.file.path, "/",run.id, dd.output.file), append=TRUE, sep="") # file.path builds the path to the file and creates the file
#############################
# Monthly
# Create the output filename:
mm.output.file  <- paste("mm/",run.id,"_",tower.name,"_stats.csv", sep="")
# Write the monthly output file:
mm.out.header<-paste("site","year","month",
                     "GPP.umol","GPP.g", "GPP.mol", 
                     "gf.PPFD.umol","gf.PPFD.mol",  "Amax", "R", "phi", 
                     "start_a","start_b", "start_c", 
                     "RsqAdj",  "fit_a", "fit_b", "fit_c",  "RMSE",
                     "ster_a", "ster_b", "ster_c",
                     "Tmean","Tmin", "Tmax", "Trange", "RH", sep=",")
write(mm.out.header, file.path(out.file.path, "/",run.id, mm.output.file), append=TRUE, sep="") # Write the header to file

}