#################################################################################################################
# DATE: 29 May, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans, Colin Prentice, Tyler W. Davis, Xavier Gilbert
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################
uid<-c(1,2,3,4,
       5,6,7,8,
       9,10,11,12,          
       13,14,15,16)
site<-c("VirginiaPark","HowardSprings","Tumbarumba","WallabyCreek",
        "AdelaideRiver","DalyRiverSavanna","Otway","SturtPlains",
        "DalyRiverPasture","AliceSprings","Calperum","Dargo",          
        "DryCreek","Nimmo","WombatStateForest","RiggsCreek")   
full<-c("Virginia Park","Howard Springs","Tumbarumba","Wallaby Creek",
        "Adelaide River","DalyRiver Savanna","Otway","Sturt Plains",
        "DalyRiver Pasture","Alice Springs","Calperum","Dargo",          
        "Dry Creek","Nimmo","Wombat State Forest","Riggs Creek")
lat<-c(-19.883333,-12.495200,-35.656611,-36.673233,
       -13.076900,-14.159200,-38.525000,-17.150688,
       -14.063333,-22.283000,-34.002717,-37.133444,          
       -15.258783,-36.215944,-37.422219,-36.649886)
lon<-c(146.553889,131.150050,148.151667,145.029372,
       131.117800,131.383383,142.810000,133.350220,
       131.318056,133.249000,140.587683,147.170917,          
       132.370567,148.552778,144.094444,145.575989)
tsf<-c(24,48,24,48,
       48,48,24,48,
       48,48,48,48,          
       48,48,48,48)
nn<-c(8,5,14,16,
       2,2,2,16,
       2,8,16,14,          
       9,16,14,14)
OzFlux<-as.data.frame(cbind(uid,site, full, lat, lon, tsf, nn), header=T)
rm(site,full,lat,lon,uid,tsf,nn)