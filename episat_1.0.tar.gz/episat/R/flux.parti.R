#  flux.parti.R
#################################################################################################################
# DATE: 30 May, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans, Colin Prentice, Tyler W. Davis, Xavier Gilbert
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################
flux.parti<-function(tower.name,out.file.path, run.id){
  # Make out.file directories
  flux.outfiles(out.file.path, run.id, tower.name)
	# Define constants
   # Read input data
   frmtd.dhT <- get(tower.name) # Gets the formated data frame for the Tower (leaves the formatted one unchanged)
   # Determine the number of years worth of data to process:
   all.years <- unique(frmtd.dhT$Year)
		# Iterate through each year 
		for (cur.year in all.years){
			# Determine the number of months to process:
			year.months <- unique(frmtd.dhT[frmtd.dhT$Year == cur.year,]$Month) 
			# Iterate through each month of year i (index == j)
			for (cur.month in year.months) {
				month.frmtd.dhT <- subset(frmtd.dhT,Year==cur.year & Month==cur.month & !is.na(PAR) & !is.na(FC))
				###################################################################
				# Check if this month's data is worth processing:
				# 1. More than 25% of observed PAR available
				# 2. More than 25% of observed PAR:FC pairs available
				###################################################################
				num.not.fp <- nrow(subset(frmtd.dhT, (Year == cur.year & Month == cur.month) & (is.na(PAR) | is.na(FC)) ))
				# Number of lines of data where both FC and PAR are observed:
				num.is.fp <- nrow(month.frmtd.dhT);
				# Number of lines of data where PAR is observed:
				num.is.p <- nrow(subset(frmtd.dhT, Year == cur.year & Month == cur.month & !is.na(PAR) ))
				# Number of lines of data where only PAR is missing:
				num.not.p <- nrow(subset(frmtd.dhT, Year == cur.year & Month == cur.month & is.na(PAR) ))
				# Only if observed PAR and observed (PAR,FC) are more than 25% of the data for the month
				if ( num.is.fp / (num.is.fp + num.not.fp) >= 0.4 && num.is.p / (num.is.p + num.not.p) >= 0.4 && num.is.fp > 2 ) {
					# Save observed FC and PPFD from filtered month's data:
					obs.fc <- month.frmtd.dhT$FC
					obs.ppfd <- month.frmtd.dhT$PAR * kParToPPFD # units of micro-moles photons * m^-2 * s^-1
					regression.results <- vector(mode="list")
					# Try the LM non-linear approach:
					nls.lm.control(maxiter = 500)
					attempt1 <- try(nlsLM(Y ~ a + b * X / (X + c), data = list(X = obs.ppfd, Y = obs.fc), start = kEstimators),  silent=TRUE)
					# Check to see if error was thrown:
					if (class(attempt1) == "try-error") {
						# Grab the error message that was thrown:
						msg <- geterrmessage()
						if(grepl("singular gradient matrix",msg)) {
							warning("Over-parameterized model, trying to optimize instead ...")
							attempt2 <- try(optim(kEstimators, flux.rss, method="BFGS", hessian=T, Y=obs.fc, X=obs.ppfd ))
							# Check to see if optim worked:
							if (class(attempt2) == 'try-error'){
								msg2 <- geterrmessage()
								stop((paste("... unhandled optim error. ",msg2)))
							} else {
								warning("... optimization complete.")
								# Retrieve regression results from optim:
								regression.results$a <- attempt2$par[["a"]]
								regression.results$b <- attempt2$par[["b"]]
								regression.results$c <- attempt2$par[["c"]]
								# Calculate regression r-squared adjusted:
								mse <- attempt2$value / (length(obs.fc) - length(kEstimators) - 1);
								mst <- var(obs.fc);
								regression.results$r2adj <- 1 - (mse/mst);
								# Calculate regression root-mean squared error:
								regression.results$rmse <- sqrt(attempt2$value / length(obs.fc));
								# Calculate standard errors for fitted parameters:
								# Assign ecological variables:
								regression.results$amax <- -(round(attempt2$par[["b"]],2))                           # -b
								regression.results$r <- round(attempt2$par[["a"]],2)                                  # a
								regression.results$phi <- round(-attempt2$par[["b"]]/attempt2$par[["c"]],3)            # b/c
							} # End try-error
              # Cat warning message
						} else {
							stop(paste("Unhandled error encountered. ",msg))
						}
					} else {
						# Retrieve regression results from LM approach:
						regression.results$a <- coef(attempt1)[["a"]]
						regression.results$b <- coef(attempt1)[["b"]]
						regression.results$c <- coef(attempt1)[["c"]]
						# Calculate regression r-squared adjusted:
						var.tot <- sum((fitted(attempt1) - mean(obs.fc))^2) / (length(fitted(attempt1)) - 1)
						var.err <- sum(summary(attempt1)$residuals^2) / (length(summary(attempt1)$residuals) - length(coef(attempt1)) -1)
						regression.results$r2adj <- 1 - (var.err / var.tot)
						# Calculate regression root-mean squared error:
						regression.results$rmse <- sqrt(sum(summary(attempt1)$residuals^2) / length(summary(attempt1)$residuals))
						# Retrieve standard errors for fitted parameters:
						regression.results$a.sterr <- summary(attempt1)$coefficients["a",2]
						regression.results$b.sterr <- summary(attempt1)$coefficients["b",2]
						regression.results$c.sterr <- summary(attempt1)$coefficients["c",2]
						# Assign ecological parameters:
						regression.results$amax <- -(round(coef(attempt1)[["b"]],2))                         # -b
						regression.results$r <- round(coef(attempt1)[["a"]],2)                               # a
						regression.results$phi <- round(-coef(attempt1)[["b"]]/coef(attempt1)[["c"]],3)      # b/c
					}
					# Find index in OzFlux for current flux tower:
        	site.index <- which(OzFlux$site == tower.name, arr.ind=TRUE)
					# Create a subset of data based on the current month and year:
					month.frmtd.dhT.withNAs <- subset(frmtd.dhT, Year == cur.year & Month == cur.month)
					# Print out the current month and year being processed:
    			cat("... ", cur.year,"/", cur.month, sep="", "\n")
					#
					if (regression.results$amax > 0){
					  #######################################
					  # Generate half hourly, daily, monthly estimates of GPP using gap filled PPFD
					  monthly.flux<-flux.gfpar(month.frmtd.dhT.withNAs, site.index, cur.year, cur.month) # Gap-fill this month's data:
					  gf.gpp.mol<-flux.gpp(regression.results, monthly.flux, month.frmtd.dhT, frmtd.dhT, tower.name, cur.year, cur.month, run.id, out.file.path)		# Calculate GPP !			
					  ######################################
            #
						# Prepare the PDF parameters:
				  		pdf(file=paste(out.file.path, "/",run.id,"/pdf/",tower.name,"_",cur.year,"_",cur.month,"_",run.id,".pdf",sep=""), paper="a4r")
						#
						# Prepare the PNG parameters:
				  		# png(paste(sOutPath,tower.name,"_",i,"_",j,"_",rid,".png",sep=""), width=600, height=600)              
						# Create the plotting space:
						par(mai=c(1.2,1,1,1))
						out.main <- paste(tower.name,":", cur.year,"/", cur.month,  sep=" ")
						#
						# Plot PPFD v PAR:
						plot(obs.ppfd, obs.fc, main = out.main,
							ylab=expression(paste("FC ","(umolCO"[2]^-1,"m"^-2,"s"^-1,")", sep="")),
							xlab=expression(paste("PPFD (umol"^-1,"m"^-2,"s"^-1,")", sep="")),
							xlim=c(0,max(obs.ppfd)),
							ylim=c(min(obs.fc),max(obs.fc)), col="#00000040", pch=19)
						#
						# Add the fitted rectangular hyperbola to the plot:
				  		lines(flux.recthyp(seq(0,3000,1), c(regression.results$a, regression.results$b, regression.results$c) ), col='#00000080', lwd=8 )
						mtext(paste("Adj.R2:",round(regression.results$r2adj,2), " RMSE:", round(regression.results$rmse,2) , sep=""), side=3, line=1)
							sGof3<-paste("GPP:",  round(gf.gpp.mol,2) , "mol/sq.m/month",
					  		"Amax:",  regression.results$amax,
					  		"phi:", regression.results$phi , #"\n",
					  		"R:", regression.results$r ,
					  		sep=" ")
						mtext(sGof3,side=3, line=0)
						dev.off()
					} # End Amax check
				} else {
					cat("... skipping (insufficient data OR bad Amax parameterisation): ", cur.year,"/", cur.month,  "\n")
				} # End check the na and zeros
			} # End ALL MONTHS loop
		} # End ALL YEARS loop
} # End Function fpart
