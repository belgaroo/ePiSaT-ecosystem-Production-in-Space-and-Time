#  const_GlobalVariables.R
#################################################################################################################
# DATE: 29 May, 2013
# This work is licensed under a Creative Commons Attribution 3.0 Attribution-NonCommercial- CC BY-NC
# URL: http://creativecommons.org/licenses/by-nc/3.0/legalcode
# SUMMARY: This license lets others remix, tweak, and build upon your work non-commercially, and although their 
# new works must also acknowledge you and be non-commercial, they don???t have to license their derivative works 
# on the same terms.
#
# REQUIRED ATTRIBUTION : DOI XXX.XXX.XXXX.XXX # Coming soon! 
# AUTHORS: Bradley Evans, Colin Prentice, Tyler W. Davis, Xavier Gilbert
# ORGANISATION: Macquarie University, Sydney Australia
# MAINTAINER: bradley.evans@mq.edu.au
# REFERENCE: 
# Evans, B.J., Prentice, I.C., Davis, T.W., Gilbert, X., 2013, Ecosystem Production in Space and Time, 
# http://episat-software.blogspot.com.au
#
#
#
# EXAMPLE: You wish to use this code or data in your own work, a peer reviewed journal article, then you need
# to attribute the work by referencing published article listed above and/ or the DOI (i.e. for output data only). 
# Contact the author if you have any questions.
#################################################################################################################
# This project is supported by the Australian National Data Service (ANDS).                                     #
# ANDS is supported by the Australian Government through the National Collaborative Research Infrastructure     #
# Strategy Program and the Education Investment Fund (EIF) Super Science Initiative.                            #
# For more information visit the ANDS website ands.org.au and Research Data Australia services.ands.org.au      #
#################################################################################################################

# ---------------------------------------- Define global variables -------------------------------------------- #
#  1. input.file.format :: regular expression used to search for input files (used in lsTowers and loadTower)
#  2. time.format :: string format for time stamps
#  3. kSWinToPar :: conversion factor for incoming shortwave radiation to PAR
#  4. kParToPPFD :: constant used to convert units of PAR to PPFD [units of micro-moles photons * m^-2 * s^-1]
#  5. kEstimators :: constant vector of hyperbola parameter estimates (f_parti.R)

## --- Define search criteria for input files --- ##
input.file.format = "^.*\\.(csv|CSV|dat|DAT|txt|TXT)$"

## --- Set the format used for time series objects --- ##
time.format <- "%Y-%m-%d %H:%M:%S"

## --- Define conversion factors --- ##
kSWinToPar <- 0.50
kParToPPFD <- 4.57

## --- Define thresholds --- ##
kPSParThresh <- 20 # Photosynthesis PAR threshold in W/m2

## --- Define regression parameters --- ##
#kEstimators <- c(a=5, b=-12, c=500)
kEstimators <- c(a=0.98, b=-12, c=1000)